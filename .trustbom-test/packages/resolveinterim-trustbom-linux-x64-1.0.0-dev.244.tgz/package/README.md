# @resolveinterim/trustbom-linux-x64

The self-contained AI TrustBOM binary for `linux-x64`. This package is an
optional dependency of `trustbom`; install `trustbom` instead of installing
this package directly. Product documentation:
https://aitrustbom.com/.

It contains only the `trustbom` binary, `LICENSE.txt`, and this file. It has no
install scripts and makes no network requests.

Run `trustbom license` to read the license terms, or see https://aitrustbom.com/legal/terms/. Privacy policy:
https://aitrustbom.com/legal/privacy/.
